import os
from modules import file_handler, xml_processor, image_modifier

def main():
    # Define paths
    project_root = os.path.dirname(os.path.abspath(__file__))
    text_files_dir = os.path.join(project_root, 'text_files')
    images_dir = os.path.join(project_root, 'images')
    output_images_dir = os.path.join(images_dir, 'output_files')
    docs_dir = os.path.join(project_root, 'docs')

    # Ensure output directory exists
    file_handler.ensure_directory(output_images_dir)

    # Clean XML file
    xml_file_path = os.path.join(text_files_dir, 'employees.xml')
    cleaned_xml_file_path = os.path.join(text_files_dir, 'employees_cleaned.xml')
    xml_content = file_handler.read_file(xml_file_path)
    cleaned_content = file_handler.clean_non_ascii(xml_content)
    file_handler.write_file(cleaned_xml_file_path, cleaned_content)

    # Process cleaned XML file
    tree = xml_processor.parse_xml(cleaned_xml_file_path)
    employees = xml_processor.get_employee_data(tree)

    # Add text to images
    image_modifier.process_images(employees, images_dir, output_images_dir)

    # Save the modified XML (if needed)
    # xml_processor.save_xml(tree, cleaned_xml_file_path)

if __name__ == "__main__":
    main()