import os

def read_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

def write_file(file_path, content):
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(content)

def clean_non_ascii(content):
    return ''.join(char for char in content if ord(char) < 128)

def ensure_directory(directory_path):
    if not os.path.exists(directory_path):
        os.makedirs(directory_path)
